#include "InnerLib.h"

int CalcFactorial(int iNo)
{
    int iCnt = 0;
    int iFactorial = 1;

    for(iCnt = 1; iCnt <= iNo; iCnt++)
    {
        iFactorial = iFactorial * iCnt;
    }

    return iFactorial;
}