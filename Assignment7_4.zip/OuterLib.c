#include "OuterLib.h"

int OpenSharedLib(int iNum)
{
    int iFactorial = 0;
    void *ptr = NULL;
    int (*fptr)(int) = NULL;

    ptr = dlopen("./InnerLib.so",RTLD_LAZY);
    if(ptr == NULL)
    {
        printf("Unable to load InnerLib.so File.\n");
        return -1;
    }

    fptr = dlsym(ptr,"CalcFactorial");
    if(fptr == NULL)
    {
        printf("Unable to load the adrress of function CalcFactorial.\n");
        return -1;
    }

    iFactorial = fptr(iNum);

    return iFactorial;
}