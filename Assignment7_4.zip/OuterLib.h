#include<stdio.h>
#include<dlfcn.h>

int OpenSharedLib(int iNum);