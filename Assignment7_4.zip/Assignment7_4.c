///////////////////////////////////////////////////////////////////////////////////////////////////////////
//Problem Statement :
//          Write a program which create shared library which internally loads other shared library.
//
//          The inner shared library provides the function to calculate the factorial of number.
//          also write the program which will load that shared library and call the function.
//////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
//
//
//          Author        :     Nilesh Balu Vidhate
//          Application   :     Application uses the nested shared libraries.
//          Input         :     integer number.
//          Output        :     Gives the factorial of that number.
//          Date          :     03/08/2023
//
//
////////////////////////////////////////////////////////////////////////

#include<stdio.h>
#include<dlfcn.h>


int main()
{
    int iFactorial = 0;
    int iNum = 0;

    void *ptr = NULL;
    int (*fptr)(int) = NULL;

    printf("Enter the integer Number : \n");
    scanf("%d",&iNum);

    if(iNum < 0)
    {
        iNum = -iNum;
    }

    ptr = dlopen("./OuterLib.so",RTLD_LAZY);
    if(ptr == NULL)
    {
        printf("Unable to load OuterLib.so Library.\n");
        return -1;
    }


    fptr = dlsym(ptr,"OpenSharedLib");
    if(fptr == NULL)
    {
        printf("Unable to load the address of function OpenSharedLib()\n");
        return -1;
    }

    iFactorial = fptr(iNum);
    
    printf("The factorial of the %d is : %d\n",iNum,iFactorial);

    return 0;

}

// gcc client.c -rdynamic -o Myexe  // Command used to create executable file from .c file if
// we are using dynamic link library. i.e .so file

// ./Myexe     // command used to run the executable file.i