#include<stdio.h>

int CalcFactorial(int);