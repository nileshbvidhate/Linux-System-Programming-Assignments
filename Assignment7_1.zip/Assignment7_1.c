////////////////////////////////////////////////////////////////////////////////////////
//Problem Statement :
//          write a Program which is used to create shared library(.SO files) and that 
//          library should be loaded at run time by the other program.
//
//          That library should contains functions to perform the arithmetic operations
//          like addition, subtraction, Division and multiplication. 
////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
//
//
//          Author        :     Nilesh Vidhate
//          Application   :     Used to demonstrate the application of shared library.
//          Input         :     Two integer numbers.
//          Output        :     Uses the shared library. i.e (.so file)
//          Date          :     29/07/2023
//
//
//
////////////////////////////////////////////////////////////////////////

#include<stdio.h>
#include<dlfcn.h>
#include<stdlib.h>

int main(int argc, char *argv[])
{   
    
    void *ptr = NULL;
    int (*fptr)(int,int);
    int iRet = 0;
    int iNo1 = 0;
    int iNo2 = 0;
    

    printf("Enter the 1st number : \n");
    scanf("%d",&iNo1);

    printf("Enter the 2st number : \n");
    scanf("%d",&iNo2);
    

    ptr = dlopen("./SharedFile.so",RTLD_LAZY);
    if(ptr == NULL)
    {
        printf("Unable to load Dynamic library.\n");
        return -1;                                                              
    }

    fptr = dlsym(ptr,"Addition");
    if(fptr == NULL)
    {
        printf("Unable to access the address of Function Addition().\n");
        return-1;
    }
    else
    {
        iRet = fptr(iNo1,iNo2);
        printf("Addition of %d and %d is : %d\n",iNo1,iNo2,iRet);
    }

    fptr = dlsym(ptr,"Subtraction");
    if(fptr == NULL)
    {
        printf("Unable to access the address of Function Subtraction().\n");
        return-1;
    }
    else
    {
        iRet = fptr(iNo1,iNo2);
        printf("Subtraction of %d and %d is : %d\n",iNo1,iNo2,iRet);
    }

    fptr = dlsym(ptr,"Multiplication");
    if(fptr == NULL)
    {
        printf("Unable to access the address of Function Multiplication().\n");
        return-1;
    }
    else
    {
        iRet = fptr(iNo1,iNo2);
        printf("Multiplication of %d and %d is : %d\n",iNo1,iNo2,iRet);
    }

    fptr = dlsym(ptr,"Division");
    if(fptr == NULL)
    {
        printf("Unable to access the address of Function Division().\n");
        return-1;
    }
    else
    {
        iRet = fptr(iNo1,iNo2);
        printf("Division of %d and %d is : %d\n",iNo1,iNo2,iRet);
    }

    dlclose(ptr);
    
    return 0;
}

// gcc client.c -rdynamic -o Myexe  // Command used to create executable file from .c file if
// we are using dynamic link library. i.e .so file

// ./Myexe     // command used to run the executable file.i