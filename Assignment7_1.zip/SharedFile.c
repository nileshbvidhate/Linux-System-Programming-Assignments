#include "SharedFile.h"

// Function Definition
int Addition(int iNo1,int iNo2)
{
    int iAns = 0;

    iAns = iNo1 + iNo2;

    return iAns;
}

// Function Definition
int Subtraction(int iNo1,int iNo2)
{
    int iAns = 0;

    iAns = iNo1 - iNo2;

    return iAns;
}

// Function Definition
int Multiplication(int iNo1,int iNo2)
{
    int iAns = 0;

    iAns = iNo1 * iNo2;

    return iAns;
}

// Function Definition

int Division(int iNo1,int iNo2)
{
    int iAns = 0;

    iAns = iNo1 / iNo2;

    return iAns;
}

//step 1. gcc -c -fPIC SharedFile.c -o SharedFile.o .        // command used to create the .o file from the .c file
// add -Wall to show the all warnings.

//step 2. gcc SharedFile.o -shared -o SharedFile.so       // command used to create the .so file from the .o file

// Step : gcc -shared -o SharedFile.so -fPIC SharedFile.c  // command used to create .so file from .c file.
// this command combines step1 and step2 commands.
