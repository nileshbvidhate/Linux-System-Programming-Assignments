///////////////////////////////////////////////////////////////////////////////////////////////////////////
//Problem Statement :
//          write a Program which is used to create 2 shared library(.SO files) and that 
//          library should be loaded at run time by the other program.
//
//          First library should contains function to check whether the input number is 
//          prime or not 
//          Second library should contains function to check whether the input number is perfect or not
//////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
//
//
//          Author        :     Nilesh Balu Vidhate
//          Application   :     Application uses the two shared libraries to check that
//                        :     given number is prime or not.
//          Input         :     integer number.
//          Output        :     It checks that number is Prime ,perfect number or not.
//          Date          :     29/07/2023
//
//
//
////////////////////////////////////////////////////////////////////////

#include<stdio.h>
#include<dlfcn.h>
#include<stdbool.h>


int main()
{
    int iNo = 0;
    int iRet = 0;
    int bFlag = false;
    
    void *ptr1 = NULL;
    void *ptr2 = NULL;
    bool (*fptr)(int) = NULL;

    printf("Enter the integer number :\n");
    scanf("%d",&iNo);
////////////////////////////////////////////////////////
    // filter
    if(iNo == 1)
    {
        printf("1 is neither Prime nor Complex number\n");
        printf("1 is not a Perfect number\n");
        return -1;
    }
////////////////////////////////////////////////////
    // Prime number

    ptr1 = dlopen("./CheckPrime.so",RTLD_LAZY);
    if(ptr1 == NULL)
    {
        printf("Unable to load Library.\n");
        return -1;
    }


    fptr = dlsym(ptr1,"CheckPrime");
    if(fptr == NULL)
    {
        printf("Unable to load the address of function CheckPrime()\n");
        return -1;
    }

    bFlag = fptr(iNo);
    if(bFlag == true)
    {
        printf("%d is a Prime Number\n",iNo);
    }
    else
    {
        printf("%d is not Prime Number\n",iNo);
    }

////////////////////////////////////////////////////////////////

    ptr2 = dlopen("./CheckPerfect.so",RTLD_LAZY);
    if(ptr2 == NULL)
    {
        printf("Unable to load Library.\n");
        return -1;
    }

    fptr = dlsym(ptr2,"CheckPerfect");
    if(fptr == NULL)
    {
        printf("Unable to load the address of function CheckPerfect()\n");
        return -1;
    }

    bFlag = fptr(iNo);
    if(bFlag == true)
    {
        printf("%d is a Perfect Number\n",iNo);
    }
    else
    {
        printf("%d is not Perfect Number\n",iNo);
    }

    return 0;
}

// gcc client.c -rdynamic -o Myexe  // Command used to create executable file from .c file if
// we are using dynamic link library. i.e .so file

// ./Myexe     // command used to run the executable file.i