#include "CheckPrimePerfect.h"

// Function Definition



bool CheckPerfect(int iNo)
{
    int iCnt = 0;
    int iNum = 0;
    bool bFlag = false;
    int iFactSum = 0;
    int iFact = 0;

    if(iNo < 0)        // Updater
    {
        iNo = -iNo;
    }

    iNum = iNo;

    for(iCnt = 1; iCnt <= (iNo/2); iCnt++)
    {
        if((iNo % iCnt) == 0)
        {
            iFactSum = iFactSum + iCnt;
            
        }
    }
   
    if(iFactSum == iNo)
    {
        bFlag = true;
    }

    return bFlag;   
}
