#include<stdio.h>
#include<stdbool.h>

//Function Declarations.
bool CheckPrime(int iNo);
bool CheckPerfect(int iNo);