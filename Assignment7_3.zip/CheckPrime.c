#include "CheckPrimePerfect.h" 

// Function Definition
bool CheckPrime(int iNo)
{
    int iCnt = 0;
    bool bFlag = true;

    if(iNo < 0)        // Updater
    {
        iNo = -iNo;
    }

    for(iCnt = 2; iCnt < iNo; iCnt++)
    {
        if((iNo % iCnt) == 0)
        {
            bFlag = false;
            break;
        }

    }

    return bFlag;
}
