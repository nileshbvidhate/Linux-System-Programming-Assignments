#include<stdio.h>

#define BLOCKSIZE 1024

// Function Declaration
int FileCompare(const char *,const char *);