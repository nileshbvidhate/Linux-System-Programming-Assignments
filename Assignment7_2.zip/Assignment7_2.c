////////////////////////////////////////////////////////////////////////////////////////
//Problem Statement :
//          write a Program which is used to create shared library(.SO files) and that 
//          library should be loaded at run time by the other program.
//
//          That library should contains functions that accept two file names from user
//          and it will compare the contents of that file.
////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////
//
//
//          Author        :     Nilesh Vidhate
//          Application   :     Used to compare the two file contents.
//          Input         :     Two file names.
//          Output        :     Compares the two file by using .so file function.
//          Date          :     29/07/2023
//
//
//
////////////////////////////////////////////////////////////////////////

#include<stdio.h>
#include<dlfcn.h>


int main()
{
    char F1[30] = {'\0'};
    char F2[30] = {'\0'};
    int iRet = 0;
    
    void *ptr = NULL;
    int (*fptr)(const char*,const char *) = NULL;

    printf("Enter the name of First file :\n");
    scanf("%s",F1);

    printf("Enter the name of second file :\n");
    scanf("%s",F2);

    ptr = dlopen("./FileCmp.so",RTLD_LAZY);
    if(ptr == NULL)
    {
        printf("Unable to load Library.\n");
        return -1;
    }


    fptr = dlsym(ptr,"FileCompare");
    if(fptr == NULL)
    {
        printf("Unable to load the address of function FileCompare()\n");
        return -1;
    }

    iRet = fptr(F1,F2);
    if(iRet == 0)
    {
        printf("Files are same.\n");
    }
    else
    {
        printf("Files are different\n");
    }

    return 0;
}

// gcc client.c -rdynamic -o Myexe  // Command used to create executable file from .c file if
// we are using dynamic link library. i.e .so file

// ./Myexe     // command used to run the executable file.i