#include "FileCmp.h"
#include<sys/stat.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>

// Function Definition
int FileCompare(const char *File1, const char *File2)
{
    struct stat Obj1;
    struct stat Obj2;
    int fd1 = 0;
    int fd2 = 0;
    char * Buffer1[BLOCKSIZE];
    char * Buffer2[BLOCKSIZE];
    int iRet = 0;

    int iAns = 0;

    printf("File Name : %s\n",File1);
    printf("File Name : %s\n",File2);

    stat(File1,&Obj1);
    stat(File2,&Obj2);

    if(Obj1.st_size != Obj2.st_size)
    {
        iAns = -1;
        return iAns;
    }
    else
    {
        fd1 = open(File1,O_RDONLY);
        fd2 = open(File2,O_RDONLY);

        if((fd1 | fd2) == -1)
        {
            printf("Unable to open file.\n");
            return -1;
        }
        else
        {
            while((iRet = read(fd1,Buffer1,BLOCKSIZE))!= 0)
            {
                read(fd2,Buffer2,BLOCKSIZE);

                if(memcmp(Buffer1,Buffer2,iRet) != 0)
                {
                    iAns = -1;
                    break;
                }
            }
        }
    }

    return iAns;
}


