#include "FileInfo.h"

void FileInformation(char *File_Name)
{
    int iRet = 0;
    struct stat Obj;

    iRet = stat(File_Name,&Obj);
    
    printf("--------------------------------------------------\n");
    printf("Information about file is :\n");
    printf("--------------------------------------------------\n");

    printf("File Name    : %s\n",File_Name);
    printf("File Size    : %ld bytes\n",Obj.st_size);
    printf("Inode Number : %ld\n",Obj.st_ino);
    printf("Link Count   : %ld\n",Obj.st_nlink);
    printf("Block Count  : %ld\n",Obj.st_blocks);
    printf("Block size   : %ld bytes\n",Obj.st_blksize);
    printf("Device ID    : %ld\n",Obj.st_dev);
    printf("User ID      : %d\n",Obj.st_uid);
    printf("Group ID     : %d\n",Obj.st_gid);

    printf("--------------------------------------------------\n");    

}

// gcc -c FileInfo.c -o FileInfo.o   /// command to create the .o file from .c file

