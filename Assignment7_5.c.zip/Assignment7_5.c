///////////////////////////////////////////////////////////////////////////////////////////////////////////
//Problem Statement :
//          Write a program which create static library which  takes file name from user and displays the 
//          information of that file.
//
//          
//////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//
//          Author        :     Nilesh Balu Vidhate
//          Application   :     Application usesd the static library.(static library creation and Use)
//          Input         :     File Name
//          Output        :     Gives the file information.
//          Date          :     03/08/2023
//
//
////////////////////////////////////////////////////////////////////////

#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/stat.h>
#include "FileInfo.h"

int main(int argc, char * argv[])
{
    char fName[20];

    printf("Enter the Name of any File : \n");
    scanf("%s",fName);

    FileInformation(fName);

    printf("The File information is displayed successfully.\n");

    return 0;
}

